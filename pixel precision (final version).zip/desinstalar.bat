@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv" (
    echo The virtual environment has already been removed. Nothing to do.
    pause
    exit /b 0
)

echo This will remove the .venv folder and its installed dependencies.
echo Your records and settings (progress.json and aim_settings.json) will be kept.
choice /M "Continue with uninstall"
if errorlevel 2 (
    echo Uninstall cancelled.
    exit /b 0
)

rmdir /s /q ".venv"
if exist ".venv" (
    echo ERROR: Could not remove .venv. Close the app and try again.
    pause
    exit /b 1
)

echo Virtual environment and dependencies removed.
pause
