"""Aplicação Flet de treino de mira 2D, com lobby e partida na mesma janela."""
# asyncio mantém a contagem regressiva sem congelar a interface.
import asyncio
# calendar calcula quantos dias existem no mês do gráfico.
import calendar
# html escapa textos inseridos no SVG para não quebrar o arquivo.
import html
# json lê e grava configurações e recordes localmente.
import json
# random escolhe novas posições para os alvos.
import random
# date e timedelta tratam datas das sessões e os últimos sete dias.
from datetime import date, timedelta
# Path monta caminhos de arquivos sem depender de barras manuais.
from pathlib import Path

# Flet cria a interface gráfica nativa da aplicação.
import flet as ft


# Pasta onde está este arquivo; os dados ficam junto ao projeto.
ROOT = Path(__file__).resolve().parent
# Arquivo persistente com cor, tamanho, sensibilidade e idioma.
SETTINGS_FILE = ROOT / "aim_settings.json"
# Arquivo persistente com recordes e sessões realizadas.
PROGRESS_FILE = ROOT / "progress.json"
# Cores usadas para o fundo, painéis, textos e destaques da interface.
BG = "#090B0F"
PANEL = "#12161D"
LINE = "#252B34"
WHITE = "#F3F5F7"
MUTED = "#89939D"
ACCENT = "#FF4655"
LIME = "#D8FF55"
# Nomes de cores disponíveis e seus valores hexadecimais.
PALETTE = {
    "Verde lima": LIME,
    "Vermelho": ACCENT,
    "Ciano": "#42E8F4",
    "Branco": "#FFFFFF",
}
# Diâmetro padrão do alvo e do círculo central que vale mais pontos.
TARGET_DIAMETER = 66
TARGET_CENTER_DIAMETER = 22
# Textos da interface em Português do Brasil e Inglês, indexados pela chave.
TEXT = {
    "pt-BR": {
        "app_name": "Pixel Precision", "brand": "PIXEL PRECISION", "lobby": "Lobby",
        "configure_aim": "Configurar mira", "main_menu": "MENU PRINCIPAL",
        "training_mode": "TREINO 2D · FLET", "ready": "PRONTO PARA TREINAR",
        "lobby_header": "PIXEL PRECISION  /  LOBBY", "room": "Área de treino",
        "hero_kicker": "PIXEL PRECISION  /  VALORANT", "hero_title": "Treine a mira.\nNo seu ritmo.",
        "hero_desc": "Pratique flicks e precisão com alvos rápidos.\nUma janela, uma mira, uma sessão de cada vez.",
        "start": "COMEÇAR TREINO", "weekly": "Progresso semanal",
        "weekly_subtitle": "PONTOS POR DIA · ÚLTIMOS 7 DIAS", "sessions": "SESSÕES",
        "record": "RECORDE PESSOAL", "per_session": "PONTOS NUMA SESSÃO",
        "this_week": "ESTA SEMANA", "monthly": "EXPORTAR GRÁFICO MENSAL",
        "download_chart": "BAIXAR GRÁFICO", "language": "IDIOMA",
        "mouse_hint": "MOVA A MIRA COM O MOUSE  ·  CLIQUE PARA ACERTAR",
        "esc_hint": "60 SEGUNDOS  ·  ESC ABRE O MENU", "points": "PONTOS",
        "time": "TEMPO", "accuracy": "PRECISÃO", "hits": "ACERTOS",
        "pause_tooltip": "Pausar treino", "menu_pause": "PIXEL PRECISION  /  PAUSA",
        "paused": "Treino pausado", "continue": "CONTINUAR",
        "back_lobby": "VOLTAR AO LOBBY", "exit": "SAIR DO JOGO",
        "finished": "SESSÃO CONCLUÍDA", "good_job": "Bom treino.",
        "play_again": "JOGAR OUTRA VEZ", "color": "COR DA MIRA",
        "change_color": "Mudar cor", "size": "TAMANHO",
        "sensitivity": "SENSIBILIDADE VALORANT", "mouse_dpi": "DPI do mouse",
        "edpi_formula": "DPI × sensibilidade", "cancel": "Cancelar", "save": "Salvar",
        "valid_input": "Insira uma sensibilidade e um DPI válidos.",
        "range_error": "Sensibilidade: 0,001–10 · DPI: 100–25600.",
        "center_hit": "CENTRO  +200", "ring_hit": "ACERTO  +100", "miss": "ERROU",
        "file_dialog": "Salvar gráfico mensal", "file_saved": "Gráfico salvo em",
        "graph_report": "PIXEL PRECISION · RELATÓRIO MENSAL",
        "daily_best": "MELHOR PONTUAÇÃO DE CADA DIA", "monthly_record": "RECORDE DO MÊS",
        "trained_days": "DIAS TREINADOS", "monthly_accuracy": "PRECISÃO",
        "no_training": "Ainda não há treinos neste mês",
        "day_names": ["SEG", "TER", "QUA", "QUI", "SEX", "SÁB", "DOM"],
        "months": ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
                   "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
    },
    "en": {
        "app_name": "Pixel Precision", "brand": "PIXEL PRECISION", "lobby": "Lobby",
        "configure_aim": "Crosshair settings", "main_menu": "MAIN MENU",
        "training_mode": "2D TRAINING · FLET", "ready": "READY TO TRAIN",
        "lobby_header": "PIXEL PRECISION  /  LOBBY", "room": "Training room",
        "hero_kicker": "PIXEL PRECISION  /  VALORANT", "hero_title": "Train your aim.\nAt your pace.",
        "hero_desc": "Practice flicks and precision with quick targets.\nOne window, one crosshair, one session at a time.",
        "start": "START TRAINING", "weekly": "Weekly progress",
        "weekly_subtitle": "POINTS PER DAY · LAST 7 DAYS", "sessions": "SESSIONS",
        "record": "PERSONAL BEST", "per_session": "POINTS IN ONE SESSION",
        "this_week": "THIS WEEK", "monthly": "EXPORT MONTHLY CHART",
        "download_chart": "DOWNLOAD CHART", "language": "LANGUAGE",
        "mouse_hint": "MOVE THE CROSSHAIR WITH THE MOUSE  ·  CLICK TO HIT",
        "esc_hint": "60 SECONDS  ·  ESC OPENS THE MENU", "points": "SCORE",
        "time": "TIME", "accuracy": "ACCURACY", "hits": "HITS",
        "pause_tooltip": "Pause training", "menu_pause": "PIXEL PRECISION  /  PAUSED",
        "paused": "Training paused", "continue": "RESUME",
        "back_lobby": "BACK TO LOBBY", "exit": "EXIT GAME",
        "finished": "SESSION COMPLETE", "good_job": "Nice work.",
        "play_again": "PLAY AGAIN", "color": "CROSSHAIR COLOR",
        "change_color": "Change color", "size": "SIZE",
        "sensitivity": "VALORANT SENSITIVITY", "mouse_dpi": "Mouse DPI",
        "edpi_formula": "DPI × sensitivity", "cancel": "Cancel", "save": "Save",
        "valid_input": "Enter a valid sensitivity and DPI.",
        "range_error": "Sensitivity: 0.001–10 · DPI: 100–25600.",
        "center_hit": "CENTER  +200", "ring_hit": "HIT  +100", "miss": "MISS",
        "file_dialog": "Save monthly chart", "file_saved": "Chart saved to",
        "graph_report": "PIXEL PRECISION · MONTHLY REPORT",
        "daily_best": "BEST SCORE EACH DAY", "monthly_record": "MONTHLY BEST",
        "trained_days": "DAYS TRAINED", "monthly_accuracy": "ACCURACY",
        "no_training": "No training sessions this month yet",
        "day_names": ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
        "months": ["January", "February", "March", "April", "May", "June",
                   "July", "August", "September", "October", "November", "December"],
    },
}
# Tradução dos nomes das cores, que também são usados nas configurações.
COLOR_LABELS = {
    "pt-BR": {"Verde lima": "Verde-limão", "Vermelho": "Vermelho", "Ciano": "Ciano", "Branco": "Branco"},
    "en": {"Verde lima": "Lime", "Vermelho": "Red", "Ciano": "Cyan", "Branco": "White"},
}


def load_settings():
    # Tenta abrir as preferências salvas na execução anterior.
    try:
        saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        saved = {}
    # Recupera a cor salva; caso não seja uma cor aceita, usa verde-limão.
    aim_color = saved.get("crosshair_color", LIME)
    if aim_color not in PALETTE.values():
        aim_color = LIME
    # Converte e limita o tamanho da mira à faixa que a interface permite.
    try:
        aim_size = min(3.5, max(1.0, float(saved.get("crosshair_size", 2.0))))
    except (TypeError, ValueError):
        aim_size = 2.0
    # Converte e limita a sensibilidade para evitar valores inválidos.
    try:
        sensitivity = min(10.0, max(0.001, float(saved.get("valorant_sensitivity", 0.35))))
    except (TypeError, ValueError):
        sensitivity = 0.35
    # Converte e limita o DPI do mouse para um intervalo razoável.
    try:
        dpi = min(25600, max(100, int(saved.get("mouse_dpi", 800))))
    except (TypeError, ValueError):
        dpi = 800
    # Devolve um conjunto completo de preferências, mesmo se faltarem dados.
    return {
        "crosshair_color": aim_color,
        "crosshair_size": aim_size,
        "valorant_sensitivity": sensitivity,
        "mouse_dpi": dpi,
        "language": saved.get("language", "pt-BR")
        if saved.get("language", "pt-BR") in TEXT else "pt-BR",
    }


def save_settings(settings):
    # Salva as preferências como JSON legível em UTF-8.
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2), encoding="utf-8")


def load_progress():
    # Lê recordes e sessões; se o arquivo estiver ausente ou danificado, começa vazio.
    try:
        data = json.loads(PROGRESS_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        data = {}
    # Garante que a lista de sessões tem o tipo esperado.
    sessions = data.get("sessions", [])
    if not isinstance(sessions, list):
        sessions = []
    # Garante que o recorde é um número inteiro não negativo.
    try:
        high_score = max(0, int(data.get("high_score", 0)))
    except (TypeError, ValueError):
        high_score = 0
    # Descarta registros que não sejam objetos e retorna os dados normalizados.
    return {
        "high_score": high_score,
        "sessions": [row for row in sessions if isinstance(row, dict)],
    }


def save_progress(progress):
    # Grava primeiro num arquivo temporário para reduzir o risco de corromper o JSON.
    temporary_file = PROGRESS_FILE.with_suffix(".tmp")
    temporary_file.write_text(json.dumps(progress, indent=2), encoding="utf-8")
    # A troca do temporário pelo arquivo final é feita ao terminar a gravação.
    temporary_file.replace(PROGRESS_FILE)


def monthly_svg(progress, month_key, language):
    # Constrói o conteúdo do gráfico mensal como SVG, usando o idioma escolhido.
    texts = TEXT[language]
    # Separa ano e mês da chave no formato AAAA-MM.
    year, month = (int(part) for part in month_key.split("-"))
    # Prepara uma posição para a melhor pontuação de cada dia do mês.
    days_in_month = calendar.monthrange(year, month)[1]
    daily_best = [0] * days_in_month
    session_count = 0
    shots = 0
    hits = 0
    trained_days = set()
    # Agrupa pontuações, acertos e tentativas das sessões do mês selecionado.
    for session in progress["sessions"]:
        try:
            session_day = date.fromisoformat(session.get("date", ""))
        except ValueError:
            continue
        if session_day.year == year and session_day.month == month:
            index = session_day.day - 1
            trained_days.add(session_day)
            daily_best[index] = max(daily_best[index], int(session.get("score", 0)))
            session_count += 1
            shots += int(session.get("shots", 0))
            hits += int(session.get("hits", 0))

    # Define a área do gráfico e calcula uma escala vertical adequada aos pontos.
    chart_left, chart_top = 100, 205
    chart_width, chart_height = 1000, 330
    max_score = max(daily_best, default=0)
    y_max = max(100, int((max_score + 99) / 100) * 100)
    step = chart_width / days_in_month
    bar_width = min(24, step * 0.62)
    # Cada item desta lista será uma linha de desenho/texto no arquivo SVG.
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700" viewBox="0 0 1200 700">',
        '<rect width="1200" height="700" fill="#090B0F"/>',
        f'<text x="70" y="72" fill="#D8FF55" font-family="Arial" font-size="14" letter-spacing="3">{html.escape(texts["graph_report"])}</text>',
        f'<text x="70" y="125" fill="#F3F5F7" font-family="Arial" font-size="34" font-weight="700">{texts["months"][month - 1]} {year}</text>',
        f'<text x="70" y="165" fill="#89939D" font-family="Arial" font-size="14">{html.escape(texts["daily_best"])}</text>',
    ]
    # Desenha as linhas horizontais e os rótulos da escala de pontuação.
    for tick in range(6):
        value = round(y_max * tick / 5)
        y = chart_top + chart_height - chart_height * tick / 5
        parts.append(f'<line x1="{chart_left}" y1="{y:.1f}" x2="{chart_left + chart_width}" y2="{y:.1f}" stroke="#252B34" stroke-width="1"/>')
        parts.append(f'<text x="{chart_left - 16}" y="{y + 5:.1f}" fill="#89939D" text-anchor="end" font-family="Arial" font-size="12">{value}</text>')
    # Desenha uma barra por dia e mostra alguns números de dia no eixo inferior.
    for index, value in enumerate(daily_best):
        x = chart_left + index * step + (step - bar_width) / 2
        height = chart_height * value / y_max
        y = chart_top + chart_height - height
        if value:
            parts.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{bar_width:.1f}" height="{height:.1f}" rx="4" fill="#D8FF55"/>')
        day_num = index + 1
        if day_num == 1 or day_num % 5 == 0 or day_num == days_in_month:
            parts.append(f'<text x="{chart_left + index * step + step / 2:.1f}" y="{chart_top + chart_height + 28}" fill="#89939D" text-anchor="middle" font-family="Arial" font-size="11">{day_num}</text>')
    # Mostra uma mensagem quando ainda não existem sessões naquele mês.
    if max_score == 0:
        parts.append(f'<text x="600" y="365" fill="#89939D" text-anchor="middle" font-family="Arial" font-size="18">{html.escape(texts["no_training"])}</text>')
    accuracy = round(hits * 100 / shots) if shots else 0
    # Prepara o resumo com recorde, sessões, dias treinados e precisão.
    summary = [
        (70, texts["monthly_record"], str(max_score)),
        (355, texts["sessions"], str(session_count)),
        (625, texts["trained_days"], str(len(trained_days))),
        (895, texts["monthly_accuracy"], f"{accuracy}%"),
    ]
    # Acrescenta os quatro indicadores à parte inferior do gráfico.
    for x, title, value in summary:
        parts.append(f'<text x="{x}" y="625" fill="#89939D" font-family="Arial" font-size="11" letter-spacing="1">{title}</text>')
        parts.append(f'<text x="{x}" y="660" fill="#F3F5F7" font-family="Arial" font-size="24" font-weight="700">{html.escape(value)}</text>')
    parts.append('</svg>')
    return "\n".join(parts).encode("utf-8")


async def main(page: ft.Page):
    # Carrega as preferências antes de definir o título e os controles iniciais.
    initial_settings = load_settings()
    page.title = TEXT[initial_settings["language"]]["app_name"]
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = BG
    page.padding = 0
    # Permite rolar o lobby se uma janela pequena não comportar todo o conteúdo.
    page.scroll = ft.ScrollMode.AUTO
    page.window.width = 1120
    page.window.height = 760
    # Define o menor tamanho permitido para manter botões e textos utilizáveis.
    page.window.min_width = 700
    page.window.min_height = 520

    # Estado temporário da partida e da interface, consultado pelos eventos.
    state = {
        "screen": "lobby",
        "settings": initial_settings,
        "progress": load_progress(),
        "current_session": None,
        "score": 0,
        "shots": 0,
        "hits": 0,
        "time_left": 60,
        "board_width": 1120,
        "board_height": 710,
        "target_diameter": TARGET_DIAMETER,
        "target_center_diameter": TARGET_CENTER_DIAMETER,
        "board_scale": 1.0,
        "aim_x": 560,
        "aim_y": 355,
        "target_x": 760,
        "target_y": 320,
    }
    # Guarda referências a controles que precisam ser atualizados durante o jogo.
    refs = {}

    def tr(key):
        # Busca a tradução da chave no idioma selecionado nas configurações.
        return TEXT[state["settings"]["language"]][key]

    def label(text, color=MUTED, size=10):
        # Cria um rótulo com a fonte monoespaçada usada nos textos auxiliares.
        return ft.Text(text, color=color, size=size, font_family="Consolas")

    def update_board_dimensions():
        # Lê o tamanho atual da área e calcula a escala visual entre 65% e 100%.
        width = max(360, page.width or 1120)
        height = max(360, page.height or 710)
        scale = max(0.65, min(1.0, width / 1120, height / 710))
        # Armazena dimensões e tamanhos proporcionais usados pelo treino.
        state["board_width"] = width
        state["board_height"] = height
        state["board_scale"] = scale
        state["target_diameter"] = TARGET_DIAMETER * scale
        state["target_center_diameter"] = TARGET_CENTER_DIAMETER * scale

    def start_round(_=None):
        # Reinicia placar, precisão e cronômetro ao começar uma nova sessão.
        state.update(screen="playing", score=0, shots=0, hits=0, time_left=60)
        # Cria o registro da sessão para que resultados sejam salvos mesmo ao sair.
        session = {
            "date": date.today().isoformat(),
            "score": 0,
            "hits": 0,
            "shots": 0,
            "completed": False,
        }
        # Adiciona a sessão em andamento aos dados persistentes.
        state["progress"]["sessions"].append(session)
        state["current_session"] = session
        save_progress(state["progress"])
        # Centraliza a mira, posiciona um alvo e mostra a tela de jogo.
        update_board_dimensions()
        state["aim_x"] = state["board_width"] / 2
        state["aim_y"] = state["board_height"] / 2
        place_target()
        render_game()

    def place_target():
        # Sorteia uma posição que mantenha o alvo inteiro dentro da área de treino.
        width = state["board_width"]
        height = state["board_height"]
        radius = state["target_diameter"] / 2 + 8
        state["target_x"] = random.uniform(radius, max(radius + 1, width - radius))
        state["target_y"] = random.uniform(100 + radius, max(101 + radius, height - radius))

    def update_score_labels():
        # Atualiza o placar e a precisão se os controles do jogo já foram criados.
        if "score" in refs:
            refs["score"].value = f'{tr("points")}  {state["score"]}'
            refs["time"].value = f'{tr("time")}  {state["time_left"]}'
            accuracy = round(state["hits"] / state["shots"] * 100) if state["shots"] else 0
            refs["accuracy"].value = (
                f'{tr("accuracy")}  {accuracy}%   •   {tr("hits")}  {state["hits"]}/{state["shots"]}'
            )

    def open_crosshair_settings(_=None):
        # Usa uma cópia temporária para só aplicar as preferências ao clicar em Salvar.
        draft = dict(state["settings"])
        color_name = next((name for name, value in PALETTE.items()
                           if value == draft["crosshair_color"]), "Verde lima")
        color_text = ft.Text(COLOR_LABELS[state["settings"]["language"]][color_name],
                             color=draft["crosshair_color"], size=15,
                             weight=ft.FontWeight.BOLD)
        size_text = ft.Text(f'{draft["crosshair_size"]:.1f}', color=WHITE, size=15)
        sensitivity_field = ft.TextField(
            label=tr("sensitivity"),
            value=f'{draft["valorant_sensitivity"]:.3f}'.rstrip("0").rstrip("."),
            width=190,
        )
        dpi_field = ft.TextField(
            label=tr("mouse_dpi"),
            value=str(draft["mouse_dpi"]),
            width=145,
        )
        edpi_text = ft.Text(
            f'eDPI: {round(draft["valorant_sensitivity"] * draft["mouse_dpi"])}',
            color=LIME,
            size=13,
        )
        dialog_preview = ft.Text("+", size=42, color=draft["crosshair_color"])

        def update_preview():
            # Reflete imediatamente a cor e tamanho escolhidos na prévia do diálogo.
            color_text.value = COLOR_LABELS[state["settings"]["language"]][color_name]
            color_text.color = draft["crosshair_color"]
            size_text.value = f'{draft["crosshair_size"]:.1f}'
            dialog_preview.color = draft["crosshair_color"]
            dialog_preview.size = 20 * draft["crosshair_size"]
            page.update()

        def update_edpi(_=None):
            # Calcula e mostra eDPI enquanto a sensibilidade e o DPI são editados.
            try:
                sens = float(sensitivity_field.value.replace(",", "."))
                dpi = int(dpi_field.value)
                edpi_text.value = f"eDPI: {round(sens * dpi)}"
            except (ValueError, AttributeError):
                edpi_text.value = "eDPI: —"
            page.update()

        sensitivity_field.on_change = update_edpi
        dpi_field.on_change = update_edpi

        def next_color(_):
            # Avança para a próxima cor da paleta e atualiza a prévia.
            nonlocal color_name
            names = list(PALETTE)
            color_name = names[(names.index(color_name) + 1) % len(names)]
            draft["crosshair_color"] = PALETTE[color_name]
            update_preview()

        def change_size(amount):
            # Ajusta o tamanho em passos, mantendo-o entre 1,0 e 3,5.
            draft["crosshair_size"] = round(
                min(3.5, max(1.0, draft["crosshair_size"] + amount)), 1
            )
            update_preview()

        def save_and_close(_):
            # Valida sensibilidade e DPI antes de salvar as novas preferências.
            try:
                sens = float(sensitivity_field.value.strip().replace(",", "."))
                dpi = int(dpi_field.value.strip())
            except (ValueError, AttributeError):
                error_text.value = tr("valid_input")
                page.update()
                return
            if not 0.001 <= sens <= 10.0 or not 100 <= dpi <= 25600:
                error_text.value = tr("range_error")
                page.update()
                return
            # Atualiza o estado, salva no disco e fecha o diálogo de configurações.
            draft["valorant_sensitivity"] = sens
            draft["mouse_dpi"] = dpi
            state["settings"] = draft
            save_settings(draft)
            page.pop_dialog()
            lobby_preview = refs.get("lobby_preview")
            if lobby_preview:
                lobby_preview.color = draft["crosshair_color"]
                lobby_preview.size = 24 * draft["crosshair_size"]
            if state["screen"] == "playing":
                update_crosshair_position()
            page.update()

        error_text = ft.Text("", color="#FF8080", size=11)

        page.show_dialog(ft.AlertDialog(
            modal=True,
            title=ft.Text(tr("configure_aim"), color=WHITE),
            bgcolor=PANEL,
            content=ft.Column([
                ft.Text(tr("color"), color=MUTED, size=10),
                ft.Row([color_text, ft.Button(tr("change_color"), on_click=next_color,
                                              bgcolor=LINE, color=WHITE)]),
                ft.Text(tr("size"), color=MUTED, size=10),
                ft.Row([
                    ft.IconButton(ft.Icons.REMOVE, on_click=lambda e: change_size(-0.2)),
                    size_text,
                    ft.IconButton(ft.Icons.ADD, on_click=lambda e: change_size(0.2)),
                    ft.Container(expand=True), dialog_preview,
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Text(tr("sensitivity"), color=MUTED, size=10),
                ft.Row([
                    sensitivity_field,
                    dpi_field,
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Row([edpi_text, ft.Container(expand=True),
                        label(tr("edpi_formula"), color=MUTED, size=10)]),
                error_text,
            ], tight=True, width=370, spacing=14),
            actions=[
                ft.TextButton(tr("cancel"), on_click=lambda e: page.pop_dialog()),
                ft.Button(tr("save"), on_click=save_and_close,
                          bgcolor=ACCENT, color=WHITE),
            ],
        ))

    def update_crosshair_position():
        # Redimensiona e posiciona a mira personalizada na coordenada atual.
        control = refs.get("crosshair")
        if not control:
            return
        size = max(24, 20 * state["settings"]["crosshair_size"] * state["board_scale"])
        control.width = size
        control.height = size
        control.left = state["aim_x"] - size / 2
        control.top = state["aim_y"] - size / 2
        control.content.size = (
            20 * state["settings"]["crosshair_size"] * state["board_scale"]
        )
        control.content.color = state["settings"]["crosshair_color"]

    def move_aim(event):
        # Ignora movimento fora da partida ou eventos sem posição do ponteiro.
        if state["screen"] != "playing" or not event.local_position:
            return
        # eDPI = sensibilidade VALORANT × DPI. 280 eDPI é a referência 1:1
        # usada pelo treino; o valor ajusta o deslocamento do ponteiro no ecrã.
        sensitivity = (
            state["settings"]["valorant_sensitivity"]
            * state["settings"]["mouse_dpi"]
            / 280
        )
        center_x = state["board_width"] / 2
        center_y = state["board_height"] / 2
        state["aim_x"] = max(0, min(
            state["board_width"],
            center_x + (event.local_position.x - center_x) * sensitivity,
        ))
        state["aim_y"] = max(0, min(
            state["board_height"],
            center_y + (event.local_position.y - center_y) * sensitivity,
        ))
        update_crosshair_position()
        page.update()

    def shoot(event):
        # Processa um clique válido e compara a mira com o centro e o anel do alvo.
        if state["screen"] != "playing" or not event.local_position:
            return
        move_aim(event)
        state["shots"] += 1
        dx = state["aim_x"] - state["target_x"]
        dy = state["aim_y"] - state["target_y"]
        # Usa distância ao quadrado para evitar calcular uma raiz quadrada.
        distance_squared = dx * dx + dy * dy
        points = 0
        # Centro branco vale 200; o restante do alvo vale 100; fora dele é erro.
        if distance_squared <= (state["target_center_diameter"] / 2) ** 2:
            state["hits"] += 1
            points = 200
            refs["feedback"].value = tr("center_hit")
            refs["feedback"].color = LIME
        elif distance_squared <= (state["target_diameter"] / 2) ** 2:
            state["hits"] += 1
            points = 100
            refs["feedback"].value = tr("ring_hit")
            refs["feedback"].color = WHITE
        else:
            refs["feedback"].value = tr("miss")
            refs["feedback"].color = MUTED
        state["score"] += points
        # Atualiza a sessão e o recorde no arquivo após cada disparo.
        session = state.get("current_session")
        if session is not None:
            session.update(score=state["score"], hits=state["hits"], shots=state["shots"])
            state["progress"]["high_score"] = max(
                state["progress"]["high_score"], state["score"]
            )
            save_progress(state["progress"])
        if points:
            place_target()
            target = refs.get("target")
            if target:
                diameter = state["target_diameter"]
                target.left = state["target_x"] - diameter / 2
                target.top = state["target_y"] - diameter / 2
        update_score_labels()
        page.update()

    def render_lobby(_=None):
        # Monta o lobby novamente, adaptando tamanhos à janela restaurada.
        state["screen"] = "lobby"
        width = page.width or 1120
        height = page.height or 710
        # A escala nunca passa de 100%; janelas menores reduzem os componentes.
        scale = max(0.72, min(1.0, width / 1120, height / 710))
        compact = width < 960
        page.clean()
        preview = ft.Text("+", size=48, color=state["settings"]["crosshair_color"])
        refs["lobby_preview"] = preview

        def change_language(event):
            # Persiste o idioma escolhido e reconstrói o lobby com os textos novos.
            language = event.control.value
            if language in TEXT:
                state["settings"]["language"] = language
                save_settings(state["settings"])
                page.title = tr("app_name")
                render_lobby()

        language_picker = ft.Dropdown(
            width=140 if compact else 175,
            value=state["settings"]["language"],
            options=[
                ft.DropdownOption(key="pt-BR", text="Português (Brasil)"),
                ft.DropdownOption(key="en", text="English"),
            ],
            on_select=change_language,
        )

        def weekly_progress_panel():
            # Prepara os sete dias recentes e os meses disponíveis para exportação.
            today = date.today()
            days = [today - timedelta(days=offset) for offset in range(6, -1, -1)]
            month_keys = {today.strftime("%Y-%m")}
            for session in state["progress"]["sessions"]:
                try:
                    month_keys.add(date.fromisoformat(session.get("date", "")).strftime("%Y-%m"))
                except ValueError:
                    continue
            available_months = sorted(month_keys, reverse=True)
            month_picker = ft.Dropdown(
                width=218,
                value=today.strftime("%Y-%m"),
                options=[
                    ft.DropdownOption(
                        key=key,
                        text=f'{TEXT[state["settings"]["language"]]["months"][int(key[5:]) - 1]} {key[:4]}',
                    )
                    for key in available_months
                ],
            )

            async def export_monthly_chart(_):
                # Gera o SVG do mês escolhido e abre a caixa de salvar do Windows.
                month_key = month_picker.value or today.strftime("%Y-%m")
                svg_bytes = monthly_svg(
                    state["progress"], month_key, state["settings"]["language"]
                )
                downloads = Path.home() / "Downloads"
                picker = ft.FilePicker()
                saved_path = await picker.save_file(
                    dialog_title=tr("file_dialog"),
                    file_name=f"pixel-precision-{month_key}.svg",
                    initial_directory=str(downloads if downloads.exists() else Path.home()),
                    file_type=ft.FilePickerFileType.CUSTOM,
                    allowed_extensions=["svg"],
                    src_bytes=svg_bytes,
                )
                if saved_path:
                    page.show_dialog(ft.SnackBar(
                        ft.Text(f"{tr('file_saved')} {saved_path}")
                    ))
            # Inicializa pontuações e contagem de sessões para cada dia desta semana.
            daily = {day.isoformat(): {"score": 0, "sessions": 0} for day in days}
            for session in state["progress"]["sessions"]:
                row = daily.get(session.get("date"))
                if row:
                    row["score"] += int(session.get("score", 0))
                    row["sessions"] += 1
            max_daily_score = max((item["score"] for item in daily.values()), default=0)
            day_names = TEXT[state["settings"]["language"]]["day_names"]
            bars = []
            week_total = 0
            week_sessions = 0
            # Cria sete barras e soma pontos/sessões para o resumo semanal.
            for day in days:
                item = daily[day.isoformat()]
                week_total += item["score"]
                week_sessions += item["sessions"]
                bar_height = 4 if not max_daily_score else max(
                    4, round(64 * item["score"] / max_daily_score)
                )
                bars.append(ft.Column([
                    ft.Container(
                        width=32 * scale, height=72 * scale, bgcolor="#20252D", border_radius=5,
                        alignment=ft.Alignment.BOTTOM_CENTER,
                        content=ft.Container(width=15 * scale, height=bar_height * scale,
                                             bgcolor=LIME, border_radius=5),
                    ),
                    label(day_names[day.weekday()], color=MUTED, size=8),
                    label(str(item["score"]), color=WHITE, size=9),
                ], spacing=5, horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                   expand=True))
            # Cartão do gráfico semanal; suas barras ocupam o espaço disponível.
            chart = ft.Container(
                expand=True,
                padding=18 * scale,
                bgcolor=PANEL,
                border=ft.Border.all(1, LINE),
                border_radius=8,
                content=ft.Column([
                    ft.Row([
                        ft.Column([
                            ft.Text(tr("weekly"), size=17 * scale, color=WHITE,
                                    weight=ft.FontWeight.BOLD),
                            label(tr("weekly_subtitle"), color=MUTED, size=9),
                        ], spacing=4),
                        ft.Container(expand=True),
                        label(f'{week_sessions} {tr("sessions")}', color=LIME, size=9),
                    ]),
                    ft.Row(bars, spacing=7, expand=True,
                           vertical_alignment=ft.CrossAxisAlignment.END),
                        ], spacing=14 * scale),
            )
            # Cartão lateral com recorde, totais e exportação do relatório mensal.
            record_card = ft.Container(
                width=220 if compact else 250,
                padding=18 * scale,
                bgcolor=PANEL,
                border=ft.Border.all(1, LINE),
                border_radius=8,
                content=ft.Column([
                    label(tr("record"), color=MUTED, size=9),
                    ft.Text(str(state["progress"]["high_score"]), size=32 * scale,
                            color=LIME, weight=ft.FontWeight.BOLD),
                    label(tr("per_session"), color=MUTED, size=8),
                    label(f'{tr("this_week")}  {week_total}', color=WHITE, size=9),
                    ft.Divider(color=LINE, height=12),
                    label(tr("monthly"), color=MUTED, size=9),
                    month_picker,
                    ft.Button(tr("download_chart"), on_click=export_monthly_chart,
                              bgcolor=LIME, color=BG, width=190 if compact else 218,
                              height=40 * scale),
                ], spacing=7),
            )
            return ft.Row([chart, record_card], spacing=14 * scale, expand=True)

        # Menu lateral encolhe no modo compacto para liberar espaço ao conteúdo.
        sidebar = ft.Container(
            width=165 if compact else 215,
            padding=16 * scale if compact else 22 * scale,
            bgcolor="#0D1015",
            border=ft.Border.only(right=ft.BorderSide(1, LINE)),
            content=ft.Column([
                ft.Row([
                    ft.Container(width=29, height=29, alignment=ft.Alignment.CENTER,
                                 bgcolor=LIME, border_radius=5,
                                 content=ft.Text("◎", color=BG, weight=ft.FontWeight.BOLD)),
                    ft.Text(tr("brand"), color=WHITE, weight=ft.FontWeight.BOLD, size=13),
                ], spacing=10),
                ft.Container(height=28 * scale),
                label(tr("main_menu")),
                ft.Container(padding=12, border_radius=6, bgcolor="#20252D",
                             content=ft.Row([
                                 ft.Icon(ft.Icons.GRID_VIEW, size=17, color=ACCENT),
                                 ft.Text(tr("lobby"), size=12, color=WHITE),
                             ], spacing=12)),
                ft.Container(on_click=open_crosshair_settings, padding=12,
                             content=ft.Row([
                                 ft.Icon(ft.Icons.GPS_FIXED, size=17, color=MUTED),
                                 ft.Text(tr("configure_aim"), size=12, color=MUTED),
                             ], spacing=12)),
                ft.Container(expand=True),
                label(tr("training_mode")),
            ], spacing=13),
        )
        # Cartão principal de boas-vindas e botão para começar a sessão.
        hero = ft.Container(
            height=285 * scale,
            padding=30 * scale,
            bgcolor=PANEL,
            border=ft.Border.all(1, LINE),
            border_radius=10,
            content=ft.Row([
                ft.Column([
                    label(tr("hero_kicker"), LIME),
                    ft.Text(tr("hero_title"), size=38 * scale, height=96 * scale,
                            weight=ft.FontWeight.BOLD, color=WHITE),
                    ft.Text(tr("hero_desc"),
                            size=12, color=MUTED),
                    ft.Row([
                        ft.Button(tr("start"), icon=ft.Icons.PLAY_ARROW,
                                  on_click=start_round, bgcolor=LIME, color=BG, height=46),
                        ft.TextButton(tr("configure_aim"), on_click=open_crosshair_settings,
                                      style=ft.ButtonStyle(color=WHITE)),
                    ], spacing=12),
                ], spacing=15 * scale, expand=True, alignment=ft.MainAxisAlignment.CENTER),
                ft.Container(
                    width=200 * scale, height=200 * scale, alignment=ft.Alignment.CENTER,
                    border=ft.Border.all(1, "#343D2B"), border_radius=100,
                    bgcolor="#161D19",
                    content=ft.Column([
                        label("PREVIEW" if state["settings"]["language"] == "en" else "PRÉVIA", color=MUTED, size=8), preview,
                        label(tr("configure_aim").upper(), color=LIME, size=8),
                    ], alignment=ft.MainAxisAlignment.CENTER,
                       horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5),
                ),
            ], spacing=24 * scale, vertical_alignment=ft.CrossAxisAlignment.CENTER),
        )
        # Organiza menu e conteúdo principal lado a lado na janela do app.
        page.add(ft.Row([
            sidebar,
            ft.Container(
                expand=True,
                padding=32 * scale,
                content=ft.Column([
                    ft.Row([
                        ft.Column([
                            label(tr("lobby_header"), LIME),
                            ft.Text(tr("room"), size=25, color=WHITE,
                                    weight=ft.FontWeight.BOLD),
                        ], spacing=5),
                        ft.Container(expand=True),
                        ft.Column([label(tr("language"), color=MUTED, size=8),
                                   language_picker], spacing=2),
                        ft.Container(width=14),
                        *([] if compact else [ft.Row([
                            ft.Container(width=7, height=7, bgcolor=LIME,
                                         border_radius=4),
                            label(tr("ready"), LIME)], spacing=8)]),
                    ]),
                    hero,
                    weekly_progress_panel(),
                    ft.Row([
                        label(tr("mouse_hint"),
                              color="#606A74", size=9),
                        ft.Container(expand=True),
                        label(tr("esc_hint"), color="#606A74", size=9),
                    ]),
                ], expand=True, spacing=18 * scale),
            ),
        ], expand=True, spacing=0))

    def resume_game(_=None):
        # Volta à partida sem zerar a pontuação ou o tempo restante.
        state["screen"] = "playing"
        render_game()

    def show_pause(_=None):
        # Troca a tela de jogo pelo menu de pausa.
        state["screen"] = "paused"
        page.clean()
        page.add(ft.Container(
            expand=True,
            alignment=ft.Alignment.CENTER,
            bgcolor=BG,
            content=ft.Container(
                width=430,
                padding=32,
                bgcolor=PANEL,
                border=ft.Border.all(1, LINE),
                border_radius=10,
                content=ft.Column([
                    label(tr("menu_pause"), LIME),
                    ft.Text(tr("paused"), size=27, color=WHITE,
                            weight=ft.FontWeight.BOLD),
                    ft.Button(tr("continue"), on_click=resume_game,
                              bgcolor=LIME, color=BG, width=360, height=46),
                    ft.Button(tr("configure_aim").upper(), on_click=open_crosshair_settings,
                              bgcolor="#20252D", color=WHITE, width=360, height=44),
                    ft.OutlinedButton(tr("back_lobby"), on_click=render_lobby,
                                      width=360, height=44),
                    ft.TextButton(tr("exit"), on_click=exit_app,
                                  style=ft.ButtonStyle(color=MUTED)),
                ], spacing=16, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            ),
        ))

    def show_results():
        # Finaliza e salva a sessão antes de mostrar a pontuação final.
        state["screen"] = "finished"
        session = state.get("current_session")
        if session is not None:
            session.update(
                score=state["score"], hits=state["hits"], shots=state["shots"],
                completed=True,
            )
            save_progress(state["progress"])
        page.clean()
        accuracy = round(state["hits"] / state["shots"] * 100) if state["shots"] else 0
        page.add(ft.Container(
            expand=True,
            alignment=ft.Alignment.CENTER,
            bgcolor=BG,
            content=ft.Container(
                width=470, padding=34, bgcolor=PANEL,
                border=ft.Border.all(1, LINE), border_radius=10,
                content=ft.Column([
                    label(tr("finished"), LIME),
                    ft.Text(tr("good_job"), size=31, color=WHITE,
                            weight=ft.FontWeight.BOLD),
                    ft.Text(f'{state["score"]} {tr("points")}', size=23, color=LIME),
                    label(f'{state["hits"]} {tr("hits")}  ·  {tr("accuracy")} {accuracy}%'),
                    ft.Button(tr("play_again"), on_click=start_round,
                              bgcolor=LIME, color=BG, width=370, height=46),
                    ft.OutlinedButton(tr("back_lobby"), on_click=render_lobby,
                                      width=370, height=44),
                    ft.TextButton(tr("exit"), on_click=exit_app,
                                  style=ft.ButtonStyle(color=MUTED)),
                ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            ),
        ))

    async def exit_app(_=None):
        # Solicita ao Flet que feche a janela nativa da aplicação.
        await page.window.close()

    def on_key(event):
        # Usa Esc para alternar entre jogo, pausa e lobby.
        if event.key not in ("Escape", "Esc"):
            return
        if state["screen"] == "playing":
            show_pause()
        elif state["screen"] == "paused":
            resume_game()
        elif state["screen"] == "finished":
            render_lobby()

    def render_game():
        # Desenha a área da partida com alvo, mira, placar e botão de pausa.
        page.clean()
        update_board_dimensions()
        diameter = state["target_diameter"]
        # Alvo visual posicionado pelo centro e dimensionado pela janela atual.
        target = ft.Container(
            left=state["target_x"] - diameter / 2,
            top=state["target_y"] - diameter / 2,
            width=diameter,
            height=diameter,
            alignment=ft.Alignment.CENTER,
            bgcolor=LIME,
            border=ft.Border.all(3, "#F3FFCC"),
            border_radius=diameter / 2,
            ignore_interactions=True,
            content=ft.Container(
                width=17 * diameter / TARGET_DIAMETER,
                height=17 * diameter / TARGET_DIAMETER,
                bgcolor="#F7FFD9", border_radius=9,
                border=ft.Border.all(1, "#829A33"),
            ),
        )
        size = max(24, 20 * state["settings"]["crosshair_size"] * state["board_scale"])
        # Mira visual própria; o ponteiro do sistema fica invisível no treino.
        aim = ft.Container(
            left=state["aim_x"] - size / 2,
            top=state["aim_y"] - size / 2,
            width=size, height=size,
            alignment=ft.Alignment.CENTER,
            ignore_interactions=True,
            content=ft.Text("+", size=20 * state["settings"]["crosshair_size"] * state["board_scale"],
                            color=state["settings"]["crosshair_color"],
                            weight=ft.FontWeight.BOLD, font_family="Consolas"),
        )
        score_text = ft.Text("", color=WHITE, size=18, weight=ft.FontWeight.BOLD)
        time_text = ft.Text("", color=WHITE, size=18, weight=ft.FontWeight.BOLD)
        accuracy_text = ft.Text("", color=MUTED, size=12)
        feedback_text = ft.Text("", color=LIME, size=13, weight=ft.FontWeight.BOLD)
        refs.update(target=target, crosshair=aim, score=score_text,
                    time=time_text, accuracy=accuracy_text, feedback=feedback_text)
        update_score_labels()

        def open_pause_button(_):
            show_pause()

        # Camada invisível que recebe movimento e cliques do mouse.
        detector = ft.GestureDetector(
            expand=True,
            content=ft.Container(expand=True, bgcolor="#0C1016"),
            on_hover=move_aim,
            on_tap=shoot,
            hover_interval=8,
            mouse_cursor=ft.MouseCursor.NONE,
        )
        # HUD e botão de pausa ficam em posições fixas sobre a área de treino.
        hud = ft.Container(
            left=28, top=22,
            ignore_interactions=True,
            content=ft.Column([score_text, accuracy_text], spacing=3),
        )
        time_display = ft.Container(
            right=91, top=28,
            ignore_interactions=True,
            content=time_text,
        )
        pause_button = ft.IconButton(
            icon=ft.Icons.PAUSE,
            icon_color=WHITE,
            icon_size=20,
            bgcolor="#20252D",
            tooltip=tr("pause_tooltip"),
            on_click=open_pause_button,
            top=18,
            right=28,
            width=44,
            height=44,
        )
        hint = ft.Container(
            bottom=18, left=0, right=0, alignment=ft.Alignment.CENTER,
            ignore_interactions=True,
            content=ft.Column([
                feedback_text,
                label(tr("mouse_hint") + "  ·  ESC",
                      color=MUTED, size=10),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=5),
        )
        # Empilha a camada de entrada, o alvo, a mira e os indicadores.
        page.add(ft.Stack(
            expand=True,
            controls=[detector, target, aim, hud, time_display, pause_button, hint],
        ))

    async def game_clock():
        # Atualiza o cronômetro uma vez por segundo sem bloquear a interface.
        while True:
            await asyncio.sleep(1)
            if state["screen"] == "playing":
                state["time_left"] = max(0, state["time_left"] - 1)
                update_score_labels()
                if state["time_left"] == 0:
                    show_results()
                else:
                    page.update()

    async def on_resize(_):
        # Espera um instante e ignora eventos intermediários do arraste da janela.
        state["resize_generation"] = state.get("resize_generation", 0) + 1
        generation = state["resize_generation"]
        await asyncio.sleep(0.12)
        if generation != state["resize_generation"]:
            return
        # Reconstrói o lobby ou redimensiona as coordenadas durante a partida.
        if state["screen"] == "lobby":
            render_lobby()
        elif state["screen"] == "playing":
            old_width = state["board_width"]
            old_height = state["board_height"]
            # Guarda posições atuais para convertê-las proporcionalmente.
            old_aim = (state["aim_x"], state["aim_y"])
            old_target = (state["target_x"], state["target_y"])
            update_board_dimensions()
            state["aim_x"] = old_aim[0] * state["board_width"] / old_width
            state["aim_y"] = old_aim[1] * state["board_height"] / old_height
            state["target_x"] = old_target[0] * state["board_width"] / old_width
            state["target_y"] = old_target[1] * state["board_height"] / old_height
            # Recria os controles do jogo com as dimensões atualizadas.
            render_game()

    # Liga os eventos do teclado e do redimensionamento, depois abre lobby e relógio.
    page.on_keyboard_event = on_key
    page.on_resize = on_resize
    render_lobby()
    page.run_task(game_clock)


if __name__ == "__main__":
    ft.run(main)
