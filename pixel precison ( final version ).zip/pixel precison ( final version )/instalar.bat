@echo off
setlocal
cd /d "%~dp0"

echo Installing Pixel Precision dependencies...

if not exist "requirements.txt" (
    echo ERROR: requirements.txt was not found in this folder.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3 -m venv .venv
    ) else (
        where python >nul 2>&1
        if errorlevel 1 (
            echo ERROR: Python was not found. Install Python 3 and try again.
            pause
            exit /b 1
        )
        python -m venv .venv
    )
    if errorlevel 1 (
        echo ERROR: Could not create the virtual environment.
        pause
        exit /b 1
    )
)

".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo ERROR: Failed to install the dependencies.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_app_shortcuts.ps1"
if errorlevel 1 (
    echo ERROR: Could not create the app icon and shortcuts.
    pause
    exit /b 1
)

echo.
echo Installation complete. Pixel Precision is available from the desktop and Start menu.
pause
