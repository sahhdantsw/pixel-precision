param([switch]$IconOnly)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$iconPath = Join-Path $root "pixel-precision-logo.ico"
$pngPath = Join-Path $root "pixel-precision-logo.png"
$pythonw = Join-Path $root ".venv\Scripts\pythonw.exe"
$appScript = Join-Path $root "lobby.py"

# Desenha a marca em alta resolução e guarda o PNG dentro de um ficheiro ICO.
Add-Type -AssemblyName System.Drawing
$bitmap = [Drawing.Bitmap]::new(256, 256)
$graphics = [Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.Clear([Drawing.Color]::Transparent)
$panel = [Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(255, 18, 22, 29))
$edge = [Drawing.Pen]::new([Drawing.Color]::FromArgb(255, 48, 59, 73), 5)
$shape = [Drawing.Drawing2D.GraphicsPath]::new()
$shape.AddArc(8, 8, 56, 56, 180, 90)
$shape.AddArc(192, 8, 56, 56, 270, 90)
$shape.AddArc(192, 192, 56, 56, 0, 90)
$shape.AddArc(8, 192, 56, 56, 90, 90)
$shape.CloseFigure()
$graphics.FillPath($panel, $shape)
$graphics.DrawPath($edge, $shape)
$red = [Drawing.Pen]::new([Drawing.Color]::FromArgb(255, 255, 70, 85), 12)
$lime = [Drawing.Pen]::new([Drawing.Color]::FromArgb(255, 216, 255, 85), 10)
$lime.StartCap = [Drawing.Drawing2D.LineCap]::Round
$lime.EndCap = [Drawing.Drawing2D.LineCap]::Round
$white = [Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(255, 243, 245, 247))
$graphics.DrawEllipse($red, 58, 58, 140, 140)
$graphics.DrawEllipse($lime, 85, 85, 86, 86)
$graphics.DrawLine($lime, 128, 30, 128, 72)
$graphics.DrawLine($lime, 128, 184, 128, 226)
$graphics.DrawLine($lime, 30, 128, 72, 128)
$graphics.DrawLine($lime, 184, 128, 226, 128)
$graphics.FillEllipse($white, 116, 116, 24, 24)
$pngStream = [IO.MemoryStream]::new()
$bitmap.Save($pngStream, [Drawing.Imaging.ImageFormat]::Png)
$pngBytes = $pngStream.ToArray()
[IO.File]::WriteAllBytes($pngPath, $pngBytes)

$iconSizes = @(256, 48, 32, 16)
$imageData = [Collections.Generic.List[byte[]]]::new()
$entries = [Collections.Generic.List[object]]::new()
$imageOffset = 6 + (16 * $iconSizes.Count)
foreach ($size in $iconSizes) {
    $frame = [Drawing.Bitmap]::new($size, $size, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $frameGraphics = [Drawing.Graphics]::FromImage($frame)
    $frameGraphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $frameGraphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $frameGraphics.DrawImage($bitmap, 0, 0, $size, $size)
    $frameGraphics.Dispose()

    $rect = [Drawing.Rectangle]::new(0, 0, $size, $size)
    $locked = $frame.LockBits($rect, [Drawing.Imaging.ImageLockMode]::ReadOnly, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $xorStream = [IO.MemoryStream]::new()
    for ($y = $size - 1; $y -ge 0; $y--) {
        $row = [byte[]]::new($size * 4)
        [Runtime.InteropServices.Marshal]::Copy([IntPtr]::Add($locked.Scan0, $y * $locked.Stride), $row, 0, $row.Length)
        $xorStream.Write($row, 0, $row.Length)
    }
    $frame.UnlockBits($locked)

    $maskStride = [int]([Math]::Ceiling($size / 32.0) * 4)
    # Os pixels BGRA já guardam o canal alfa; a máscara AND fica toda a zero.
    $andMask = [byte[]]::new($maskStride * $size)
    $frame.Dispose()

    $pixels = $xorStream.ToArray()
    $xorStream.Dispose()
    $dibStream = [IO.MemoryStream]::new()
    $dibWriter = [IO.BinaryWriter]::new($dibStream)
    $dibWriter.Write([UInt32]40)
    $dibWriter.Write([Int32]$size)
    $dibWriter.Write([Int32]($size * 2))
    $dibWriter.Write([UInt16]1)
    $dibWriter.Write([UInt16]32)
    $dibWriter.Write([UInt32]0)
    $dibWriter.Write([UInt32]($pixels.Length + $andMask.Length))
    $dibWriter.Write([Int32]0)
    $dibWriter.Write([Int32]0)
    $dibWriter.Write([UInt32]0)
    $dibWriter.Write([UInt32]0)
    $dibWriter.Write($pixels)
    $dibWriter.Write($andMask)
    $dibBytes = $dibStream.ToArray()
    $dibWriter.Dispose()
    $dibStream.Dispose()

    $entries.Add([pscustomobject]@{ Size = $size; Length = $dibBytes.Length; Offset = $imageOffset })
    $imageData.Add($dibBytes)
    $imageOffset += $dibBytes.Length
}
$graphics.Dispose()
$bitmap.Dispose()

$iconStream = [IO.MemoryStream]::new()
$writer = [IO.BinaryWriter]::new($iconStream)
$writer.Write([UInt16]0)
$writer.Write([UInt16]1)
$writer.Write([UInt16]$iconSizes.Count)
for ($i = 0; $i -lt $entries.Count; $i++) {
    $entry = $entries[$i]
    $dimension = if ($entry.Size -eq 256) { [byte]0 } else { [byte]$entry.Size }
    $writer.Write($dimension)
    $writer.Write($dimension)
    $writer.Write([byte]0)
    $writer.Write([byte]0)
    $writer.Write([UInt16]1)
    $writer.Write([UInt16]32)
    $writer.Write([UInt32]$entry.Length)
    $writer.Write([UInt32]$entry.Offset)
}
foreach ($bytes in $imageData) { $writer.Write($bytes) }
[IO.File]::WriteAllBytes($iconPath, $iconStream.ToArray())
$writer.Dispose()
$iconStream.Dispose()
$pngStream.Dispose()
$pngStream = $null
if ($IconOnly) { return }

# Cria atalhos no menu Iniciar e no ambiente de trabalho.
$shell = New-Object -ComObject WScript.Shell
$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Pixel Precision.lnk"
$desktop = Join-Path ([Environment]::GetFolderPath("Desktop")) "Pixel Precision.lnk"
foreach ($shortcutPath in @($startMenu, $desktop)) {
    Remove-Item -LiteralPath $shortcutPath -Force -ErrorAction SilentlyContinue
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $pythonw
    $shortcut.Arguments = "`"$appScript`""
    $shortcut.WorkingDirectory = $root
    $shortcut.Description = "Pixel Precision aim trainer"
    $shortcut.IconLocation = "$iconPath,0"
    $shortcut.Save()
}

# Notifica o Windows Shell para atualizar os ícones apresentados no ambiente de trabalho.
Add-Type -Namespace PixelPrecision -Name ShellNotify -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("shell32.dll")]
public static extern void SHChangeNotify(int eventId, uint flags, System.IntPtr item1, System.IntPtr item2);
"@
[PixelPrecision.ShellNotify]::SHChangeNotify(0x08000000, 0x0000, [IntPtr]::Zero, [IntPtr]::Zero)
