@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv" (
    echo The virtual environment has already been removed. Nothing to do.
    pause
    exit /b 0
)

echo This will remove the .venv folder and its installed dependencies.
echo The Pixel Precision shortcuts and icon will also be removed.
echo Your records and settings (progress.json and aim_settings.json) will be kept.
choice /M "Continue with uninstall"
if errorlevel 2 (
    echo Uninstall cancelled.
    exit /b 0
)

rmdir /s /q ".venv"
if exist ".venv" (
    echo ERROR: Could not remove .venv. Close the app and try again.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$paths = @((Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Pixel Precision.lnk'), (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Pixel Precision.lnk')); Remove-Item -LiteralPath $paths -Force -ErrorAction SilentlyContinue"
del /q "pixel-precision-logo.ico" 2>nul
del /q "pixel-precision-logo.png" 2>nul

echo Virtual environment, shortcuts, and generated app icons removed.
pause
